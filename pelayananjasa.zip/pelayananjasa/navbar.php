<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    
    <!-- bootstrap  -->
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous"> -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/glide.core.min.css">
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css" />
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />

    <!-- roboto -->
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700;900&display=swap" rel="stylesheet">
    <!-- londrina -->
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Londrina+Solid:wght@900&family=Roboto:wght@300;400;700;900&display=swap" rel="stylesheet">
    
    <link rel="icon" type="img/png" href="img/title.png">
    <title>Desainer Milenial | 2021</title>
    <style>
      /* Back To Top Pure JS by igniel.com */
      #ignielToTop {
        display: none;
        z-index: 2;
        position: fixed;
        bottom: 110px;
        right: 20px;
        border-radius: 2px;
        cursor: pointer;
        opacity: 0.3;
        transition: all 0.4s;
        width: 35px;
        height: 35px;
        background: #ed2849
          url("data:image/svg+xml,%3Csvg viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M7.41,15.41L12,10.83L16.59,15.41L18,14L12,8L6,14L7.41,15.41Z' fill='%23fff'/%3E%3C/svg%3E")
          no-repeat center center;
      }

      nav ul li a:hover {
        border-bottom: 3px solid white;
      }

      .bi-twitter, .bi-instagram {
        background-color: #383838;
        padding: 4px 7px;
        border-radius: 6px;
      }

      .bi-twitter:hover {
        background-color: #03adfc;
      }

       .bi-instagram:hover {
        background-color: #b80697;
      }
      
    </style>
    <script type="text/javascript">window.$crisp=[];window.CRISP_WEBSITE_ID="607aff2b-f33e-454b-9c0f-41d39c41f6c0";(function(){d=document;s=d.createElement("script");s.src="https://client.crisp.chat/l.js";s.async=1;d.getElementsByTagName("head")[0].appendChild(s);})();</script>
  </head>
  <body style="font-family: 'Roboto', sans-serif;">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top shadow">
      <div class="container-sm">
        <img src="img/logo.png" width="250" class="navbar-brand">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav" style="font-size:larger;">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link pr-3 font-weight-bold text-warning" style="font-family:'Londrina Solid', cursive;" href="index.php"><i class="bi bi-house-fill"></i>Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link  pr-3 font-weight-bold" href="wpap.php">Wpap</a>
            </li>
            <li class="nav-item">
              <a class="nav-link  pr-3 font-weight-bold" href="sketch.php">Sketch</a>
            </li>
            <li class="nav-item">
              <a class="nav-link  pr-3 font-weight-bold" href="lukisan.php">Lukisan warna</a>
            </li>
            <li class="nav-item">
              <a class="nav-link  pr-3 font-weight-bold" href="testimoni.php">Testimoni</a>
            </li>
            <li class="nav-item">
              <a class="nav-link font-weight-bold" href="about.php">About</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- Akhir navbar -->