<?php 
// Koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "pelayananjasa");


function query2($query2) {
    global $conn;
    $result = mysqli_query($conn, $query2);
    $rows = [];
    while ( $row = mysqli_fetch_assoc($result) ) {
        $rows[] = $row;
    }
    return $rows;
}


function tambah($data) {
  global $conn;
  $nama = htmlspecialchars($data["nama"]);
  $email = htmlspecialchars($data["email"]);
  $nohp = htmlspecialchars($data["nohp"]);

  // upload gambar
  $gambar = upload2();
  if (!$gambar) {
      return false;
  }   

  $kategori = htmlspecialchars($data["kategori"]);

  $query2 = "INSERT INTO pesanan 
            VALUES
            ('$nama', '$email', '$nohp', '$gambar', '$kategori')
            ";
  mysqli_query($conn, $query2);

  return mysqli_affected_rows($conn);
}


function upload2() {
    
    $namaFile = $_FILES['gambar']['name'];
    $ukuranFile = $_FILES['gambar']['size'];
    $error = $_FILES['gambar']['error'];
    $tmpName = $_FILES['gambar']['tmp_name'];

    // cek apakah tidak ada gambar yang diupload
    if ($error === 4) {
        echo "<script>
                alert('Pilih gambar terlebih dahulu');
              </script>";
        return false;
    }

    // cek apakah yang diupload gambar atau bukan
    $ekstensiGambarValid = ['jpg', 'jpeg', 'png'];
    $ekstensiGambar = explode('.', $namaFile);
    $ekstensiGambar = strtolower(end($ekstensiGambar));
    if ( !in_array($ekstensiGambar, $ekstensiGambarValid) ) {
        echo "<script>
                alert('Yang anda upload bukan gambar');
              </script>";
        return false;
    }

    // cek jika ukurannya terlalu besar
    if ($ukuranFile > 8000000 ) {
        echo "<script>
                  alert('Ukuran gambar terlalu besar');
              </script>";
        return false;
    }

    // lolos pengecekan, gambar siap diupload
    // generate nama gambar baru
    $namaFileBaru = uniqid();
    $namaFileBaru .= '.';
    $namaFileBaru .= $ekstensiGambar;

    move_uploaded_file($tmpName, 'img/' . $namaFileBaru);

    return $namaFileBaru;

}


function hapus2($email) {
    global $conn;
    mysqli_query($conn, "DELETE FROM pesanan WHERE email = '$email'");
    return mysqli_affected_rows($conn);
}


function ubah2($data2) {
    global $conn;

    $nama = htmlspecialchars($data2["nama"]);
    $email = htmlspecialchars($data2["email"]);
    $nohp = htmlspecialchars($data2["nohp"]);
    $gambarLama = htmlspecialchars($data2["gambarLama"]);

    // cek apakah user pilih gambar baru atau tidak
    if ( $_FILES['gambar']['error'] === 4 ) {
        $gambar = $gambarLama;
    } else {
        $gambar = uploadpesanan();
    }

    $kategori = htmlspecialchars($data2["kategori"]);
  
    $query2 = "UPDATE pesanan SET
              nama = '$nama', 
              email = '$email', 
              nohp = '$nohp', 
              gambar = '$gambar', 
              kategori = '$kategori'
              WHERE email = '$email'
              ";
    mysqli_query($conn, $query2);
  
    return mysqli_affected_rows($conn);
}

// upload gambar yang telah diubah pesanan
function uploadpesanan() {
    
    $namaFile = $_FILES['gambar']['name'];
    $ukuranFile = $_FILES['gambar']['size'];
    $error = $_FILES['gambar']['error'];
    $tmpName = $_FILES['gambar']['tmp_name'];

    // cek apakah tidak ada gambar yang diupload
    if ($error === 4) {
        echo "<script>
                alert('Pilih gambar terlebih dahulu');
              </script>";
        return false;
    }

    // cek apakah yang diupload gambar atau bukan
    $ekstensiGambarValid = ['jpg', 'jpeg', 'png'];
    $ekstensiGambar = explode('.', $namaFile);
    $ekstensiGambar = strtolower(end($ekstensiGambar));
    if ( !in_array($ekstensiGambar, $ekstensiGambarValid) ) {
        echo "<script>
                alert('Yang anda upload bukan gambar');
              </script>";
        return false;
    }

    // cek jika ukurannya terlalu besar
    if ($ukuranFile > 8000000 ) {
        echo "<script>
                  alert('Ukuran gambar terlalu besar');
              </script>";
        return false;
    }

    // lolos pengecekan, gambar siap diupload
    // generate nama gambar baru
    $namaFileBaru = uniqid();
    $namaFileBaru .= '.';
    $namaFileBaru .= $ekstensiGambar;

    move_uploaded_file($tmpName, '../img/' . $namaFileBaru);

    return $namaFileBaru;

}



?>