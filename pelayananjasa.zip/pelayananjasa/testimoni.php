<?php 
require 'admin/function.php';

$portofolio = query("SELECT * FROM portofolio WHERE kategori='testimoni'");
?>
   
    <!-- navbar -->
    <?php  
    include 'navbar.php';
    ?>
    <!-- akhir navbar -->

    <!-- background -->
    <section
      class="background mw-100"
      style="margin-top: 70px; background-position: center; background-repeat: no-repeat; background-size: cover; position: relative; background-image: url(img/header.jpg); height: 600px"
    >
      <div class="container text-center">
        <div class="col-sm">
          <h2 style="color: white; opacity: 0.8; font-weight: bold; text-align: center; padding-top: 150px"></h2>
          <img src="img/logo.png" data-aos="zoom-in" width="100%" />
        </div>
      </div>
    </section>
    <!-- akhir background -->

    <!-- testimoni -->
    <section class="portofolio">
      <div class="container-fluid">
        <div class="row text-center mb-5" style="padding-top: 100px">
          <div class="col">
            <h2 class="font-weight-bold text-danger" data-aos="fade-down">Testimoni</h2>
          </div>
        </div>
        <div class="col text-center">
        <?php foreach ($portofolio as $row ) : ?>
          <img src="img/<?= $row["gambar"]; ?>" class="img-thumbnail m-3 shadow" width="300" data-aos="flip-right"> 
        <?php endforeach; ?>
        </div>
      </div>
    </section>
    <!-- akhir testimoni -->
    
    <!-- footer -->
    <?php 
    include 'footer.php';
    ?>
    <!-- akhir footer -->
