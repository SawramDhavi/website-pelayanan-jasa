<!-- cara pesan -->
    <?php 
      $accordion = query2("SELECT * FROM accordion WHERE kategori='pesanan'");
    ?>
    <section>
      <div class="container mt-5">
        <div class="row">
          <div class="col-sm text-center mb-5">
            <h2 class="font-weight-bold" data-aos="fade-down">Bagaimana cara memesan <span class="text-danger">jasa kami ?</span></h2>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-6">
            <img src="img/carapesan.jpg" width="100%" data-aos="zoom-in-down">
          </div>
          <div class="col-sm-6 mb-3">
            <div class="accordion shadow-sm" id="accordionExample" data-aos="fade-left">
              <?php foreach ($accordion as $accord) : ?>
                <div class="card">
                  <div class="card-header" id="<?= $accord["id"]; ?>">
                    <h2 class="mb-0">
                      <button class="btn btn-block text-left colapsed" type="button" data-toggle="collapse" data-target="#<?= $accord["collapse"]; ?>" aria-expanded="false" aria-controls="<?= $accord["collapse"]; ?>">
                        <!-- <h5><i class="bi bi-caret-down-fill"></i> Isi form pemesanan</h5> -->
                        <h5>+ <?= $accord["judul"]; ?></h5>
                      </button>
                    </h2>
                  </div>
                  <div id="<?= $accord["collapse"]; ?>" class="collapse" aria-labelledby="<?= $accord["id"]; ?>" data-parent="#accordionExample">
                    <div class="card-body">
                      <p><?= $accord["pesan"]; ?></p>
                    </div>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
        </div>
      </div>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#e7003e" fill-opacity="1" d="M0,224L60,234.7C120,245,240,267,360,261.3C480,256,600,224,720,181.3C840,139,960,85,1080,53.3C1200,21,1320,11,1380,5.3L1440,0L1440,320L1380,320C1320,320,1200,320,1080,320C960,320,840,320,720,320C600,320,480,320,360,320C240,320,120,320,60,320L0,320Z"></path></svg>
    </section>
    <!-- akhir cara pesan -->

    <!-- form pemesanan -->
    <section>
    <div class="container-fluid" style="background-color: #e7003e;">
        <div class="container pt-5">
            <div class="row">
                <div class="col-sm-6 offset-sm-3 bg-light p-5 rounded shadow-lg">
                <h2 class="font-weight-bold text-center mb-5" data-aos="fade-down">Form <span class="text-danger"> pemesanan</span></h2>
                  <form action="" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                      <label for="nama">Nama</label>
                      <input type="text" name="nama" class="form-control" id="nama" required> 
                    </div>
                    <div class="form-group">
                      <label for="email">E-mail</label>
                      <input type="text" name="email" class="form-control" id="email" required> 
                    </div>
                    <div class="form-group">
                      <label for="nohp">No Hp</label>
                      <input type="text" name="nohp" class="form-control" id="nohp" required>
                    </div>
                    <div class="form-group">
                      <label for="gambar">Pilih gambar</label>
                      <input type="file" class="form-control-file" name="gambar" id="gambar" required>
                    </div>
                    <div class="input-group mb-3">
                      <div class="input-group-prepend">
                        <label class="input-group-text" for="inputGroupSelect01">Kategori</label>
                      </div>
                      <select class="custom-select" name="kategori">
                        <option selected>Pilih ...</option>
                        <option>wpap</option>
                        <option>sketch</option>
                        <option>lukisan</option>
                      </select>
                    </div>
                    <p>Terimakasih telah mengisi Formulir Pemesanan. Jika data sudah Lengkap, silahkan tekan tombol "SELESAI" di bawah. Selanjutnya tim kami akan segera menghubungimu lewat WhatsApp</p>
                    <button type="submit" name="submit2" class="btn btn-danger">Selesai</button>
                  </form>
                </div>
            </div>
        </div>
    </div>
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#e7003e" fill-opacity="1" d="M0,192L48,181.3C96,171,192,149,288,170.7C384,192,480,256,576,256C672,256,768,192,864,186.7C960,181,1056,235,1152,245.3C1248,256,1344,224,1392,208L1440,192L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z"></path></svg>
    </section>
    <!-- akhir form pemesanan -->