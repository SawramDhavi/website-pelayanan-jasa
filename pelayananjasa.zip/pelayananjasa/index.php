    <?php 
    require 'function-pesanan.php';

    $accordion = query2("SELECT * FROM accordion WHERE kategori='umum'");
    ?>
    
    <!-- navbar -->
    <?php  
    include 'navbar.php';
    ?>
    <!-- akhir navbar -->

    <!-- background -->
    <section class="background mw-100" style="margin-top: 70px; background-position: center; background-repeat: no-repeat; background-size:cover; background-position: center; position:relative; background-attachment: fixed;  background-image: url(img/header.jpg); height: 600px;">
      <div class="container text-center">
        <div class="col-sm">
          <h1 style=" color: white; opacity: 0.8; font-weight: bold; text-align: center; padding-top: 140px;">Jasa Gambar / melukis online</h1>
          <h3 style=" color: white; opacity: 0.8; font-weight: bold; text-align: center;"></h3>
          <button type="button" class="btn btn-danger mr-3 mt-4"><a href="wpap.php" style="text-decoration: none; color:white">Pesan Wpap</a></button>
          <button type="button" class="btn btn-warning mr-3 mt-4"><a href="sketch.php" style="text-decoration: none; color: black">Pesan Sketch</a></button>
          <button type="button" class="btn btn-primary mt-4"><a href="lukisan.php" style="text-decoration: none; color:white">Pesan Lukisan</a></button>
        </div>
      </div>
    </section>
    <!-- akhir background -->

    <!--  tentang kami -->
    <section class="tentang-kami">
      <div class="container-fluid">
        <div class="row text-center mb-5" style="padding-top: 100px">
          <div class="col">
            <h2 class="font-weight-bold text-danger" data-aos="fade-down">Mengapa memilih kami ?</h2>
          </div>
        </div>
        <div class="row text-center">
          <div class="col" data-aos="fade-right">
            <span class="fa-stack fa-2x mb-3">
              <i class="fas fa-circle fa-stack-2x text-danger"></i>
              <i class="fas fa-user-check fa-stack-1x text-white"></i>
            </span>
            <h5>Berpengalaman</h5>
            <p>Hasil desain kami jamin akan memuaskan, lihat dan buktikan sendiri ya!</p>
          </div>
          <div class="col" data-aos="fade-up">
            <span class="fa-stack fa-2x mb-3">
              <i class="fas fa-circle fa-stack-2x text-danger"></i>
              <i class="fas fa-hand-holding-usd fa-stack-1x text-white"></i>
            </span>
            <h5>Harga terjangkau</h5>
            <p>Harga yang kami sangat murah dan ada diskon setiap order banyak.</p>
          </div>
          <div class="col" data-aos="fade-left">
            <span class="fa-stack fa-2x mb-3">
              <i class="fas fa-circle fa-stack-2x text-danger"></i>
              <i class="fas fa-hourglass fa-stack-1x text-white"></i>
            </span>
            <h5>Pengerjaanya cepat</h5>
            <p>Pengerjaan desain hanya 1 hari tergantung banyaknya antrian pemesanan</p>
          </div>
        </div>
      </div>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
        <path
          fill="#e7003e"
          fill-opacity="1"
          d="M0,192L48,197.3C96,203,192,213,288,229.3C384,245,480,267,576,250.7C672,235,768,181,864,181.3C960,181,1056,235,1152,234.7C1248,235,1344,181,1392,154.7L1440,128L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
        ></path>
      </svg>
    </section>
    <!-- akhir tentang kami -->

    <!-- kontent -->
    <section>
      <div class="container-fluid" style="background-color: #e7003e">
        <div class="row">
          <div class="col-sm-5 offset-1">
            <h1 class="text-white" style="font-weight: 900;" data-aos="zoom-in-up" data-aos-easing="linear" data-aos-duration="1200">
              “Enabling Happiness and Productivity at Home”<span style="color: black"> #StayAtHome</span>
            </h1>
          </div>
          <div class="col-sm-3 offset-2">
            <img src="img/coronavirus.png" data-aos="fade-left" data-aos-easing="linear" data-aos-duration="3000" />
          </div>
        </div>
      </div>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
        <path
          fill="#e7003e"
          fill-opacity="1"
          d="M0,160L80,138.7C160,117,320,75,480,53.3C640,32,800,32,960,53.3C1120,75,1280,117,1360,138.7L1440,160L1440,0L1360,0C1280,0,1120,0,960,0C800,0,640,0,480,0C320,0,160,0,80,0L0,0Z"
        ></path>
      </svg>
    </section>
    <!-- konten -->

    <!-- Deskripsi singkat-->
    <article>
      <div class="container-sm bg-dark shadow p-5 rounded mb-5">
        <div class="row text-center mb-3">
          <div class="col">
            <h1 class="font-weight-bold text-danger" data-aos="fade-down">APA ITU WPAP ?</h1>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-3 offset-1 pb-3">
            <img src="img/wpap.jpg" width="100%" style="box-shadow: 0px 0px 10px white" data-aos="zoom-in" />
          </div>
          <div class="col-sm-7 offset-1">
            <p class="text-white" data-aos="fade-left" style="text-align: justify;">
              WPAP atau kependekan dari Wedha's Pop Art Potrait merupakan WPAP atau Wedha’s Pop Art Potrait merupakan seni ilustrasi potret yang didominasi bidang datar marak warna depan, tengah dan
              belakang untuk menimbulkan dimensi kotak-kotak. Seni ini dibentuk dari garis imajiner tegas menyesuaikan bentuk wajah dan letak elemen anggota wajah lainnya, namun proporsinya tetap sama
              dengan gambar aslinya. Namun tracingnya dibuat kreatif dan tracing ini tidak 100% sama dengan komposisi gambar aslinya. Hasil final dari objek transformasi tetap jelas dan menyerupai
              gambar aslinya, tentunya mudah dikenali. Untuk saat ini jenis lukisan ini sedang naik daun, artinya banyak dari anak muda sampai dewasa suka dengan lukisan popart WPAP ini karena nilai
              seninya tinggi dan punya ciri ke khas an daripada jenis lukisan wajah lain. Maka dari itu kenapa jasa lukis wajah WPAP sangat laris di pasaran baik lokal maupun mancanegara. Biasanya
              anak-anak muda menggunakan lukisan ini untuk kado/hadiah ulang tahun, wisuda, anniversary, dan lain-lain.
            </p>
            <h4 class="text-danger font-weight-bold">Mau Order ?</h4>
            <button type="button" class="btn btn-danger"><a href="wpap.php" style="text-decoration: none; color:white">Klik Disini!</a></button>
          </div>
        </div>
      </div>
      <div class="container-sm bg-dark shadow-lg p-5 rounded mb-5">
        <div class="row text-center mb-3">
          <div class="col">
            <h1 class="font-weight-bold text-danger" data-aos="fade-down">APA ITU SKETCH ?</h1>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-4 pb-3">
            <img src="img/sketch.jpg" width="100%" style="box-shadow: 0px 0px 10px #e7003e" data-aos="zoom-in" />
          </div>
          <div class="col-sm-7 offset-1">
            <p class="text-white" data-aos="fade-left" style="text-align: justify;">
              Sketch adalah karya gambar yang biasanya tidak dimaksudkan sebagai hasil karya akhir. Sebuah sketsa dapat memiliki beberapa tujuan yaitu merekam sesuatu yang dilihat oleh seniman, merekam atau
              mengembangkan gagasan untuk dipakai kemudian, atau dapat juga digunakan sebagai cara singkat menggambarkan citra, gagasan, atau prinsip. Sketsa dapat dibuat pada beragam media gambar.
              Istilah ini sering diterapkan pada karya grafis yang dikerjakan pada media kering, seperti silverpoint, grafit, pensil, arang, atau pastel, namun dapat juga diterapkan pada gambar yang
              dikerjakan menggunakan pena dan tinta, pena ballpoint, cat air, dan cat minyak. Dua jenis terakhir umumnya disebut sebagai "skesa cat air" atau "sketsa cat minyak". Seorang pematung
              dapat juga membuat sketsa model tiga dimensi dari tanah liat, plastisin, atau wax.
            </p>
            <h4 class="text-danger font-weight-bold">Mau Order ?</h4>
            <button type="button" class="btn btn-danger"><a href="sketch.php" style="text-decoration: none; color:white">Klik Disini!</a></button>
          </div>
        </div>
      </div>
      <div class="container-sm bg-dark shadow-lg p-5 rounded mb-3">
        <div class="row text-center mb-3">
          <div class="col">
            <h1 class="font-weight-bold text-danger" data-aos="fade-down">APA ITU LUKISAN WARNA ?</h1>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-4 pb-3">
            <img src="img/lukisan.png" width="100%" style="box-shadow: 0px 0px 10px white" data-aos="zoom-in" />
          </div>
          <div class="col-sm-7 offset-1">
            <p class="text-white" data-aos="fade-left" style="text-align: justify;">
              Lukisan digital adalah bentuk seni yang sedang berkembang di mana teknik melukis tradisional seperti cat air , minyak , impasto , dll diterapkan menggunakan alat digital melalui komputer
              , tablet grafik dan stylus , dan perangkat lunak . Seni lukis tradisional adalah seni lukis dengan media fisik sebagai lawan dari gaya yang lebih modern seperti digital. Lukisan digital
              berbeda dengan bentuk seni digital lainnya , terutama seni yang dihasilkan komputer, karena tidak melibatkan rendering komputer dari model. Seniman menggunakan teknik melukis untuk
              membuat lukisan digital langsung di komputer. Semua program lukisan digital mencoba meniru penggunaan media fisik melalui berbagai kuas dan efek cat. Termasuk dalam banyak program adalah
              kuas yang ditata secara digital untuk mewakili gaya tradisional seperti minyak, akrilik, pastel, arang, pena, dan bahkan media seperti airbrushing. Ada juga efek tertentu yang unik untuk
              setiap jenis cat digital yang menggambarkan efek realistis misalnya cat air pada lukisan 'cat air' digital. [1]Di sebagian besar program lukisan digital, pengguna dapat membuat gaya kuas
              mereka sendiri menggunakan kombinasi tekstur dan bentuk. Kemampuan ini sangat penting untuk menjembatani gap antara seni lukis tradisional dan digital.
            </p>
            <h4 class="text-danger font-weight-bold">Mau Order ?</h4>
            <button type="button" class="btn btn-danger"><a href="lukisan.php" style="text-decoration: none; color:white">Klik Disini!</a></button>
          </div>
        </div>
      </div>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
        <path
          fill="#e7003e"
          fill-opacity="1"
          d="M0,192L60,176C120,160,240,128,360,128C480,128,600,160,720,186.7C840,213,960,235,1080,229.3C1200,224,1320,192,1380,176L1440,160L1440,320L1380,320C1320,320,1200,320,1080,320C960,320,840,320,720,320C600,320,480,320,360,320C240,320,120,320,60,320L0,320Z"
        ></path>
      </svg>
    </article>
    <!-- akhir deskripsi -->

    <!-- testimoni2 -->
    <section>
      <div class="container-fluid pb-5" style="background-color: #e7003e;">
        <div class="row text-center">
          <div class="col-sm">
            <h2 class="font-weight-bold text-white mb-5" data-aos="fade-down">Testimoni pelanggan</h2>
          </div>
        </div>
        <div class="row text-center">

          <div class="glide">
            <div class="glide__track" data-glide-el="track">
              <ul class="glide__slides">
                <li class="glide__slide">
                  <div class="p-5">
                    <div class="card shadow-lg" style="width: 18rem; background-image: linear-gradient(to right, #e5e6e8, #28f7f7);" data-aos="fade-right">
                      <div class="card-body">
                        <img class="rounded-circle img-thumbnail" src="img/alipa.jpeg" width="100" style="margin-top: -65px;">
                        <h6 class="card-subtitle mb-3 mt-3 text-muted">Alifa Maulida</h6>
                        <p class="card-text">Desainnya sesuai dengan ekspetasi, proses mudah tidak ribet, elegan, sederhana tp berkelas .. Like it!!
                          Terimakasih kak. Sukses buat kedepannya yaa..</p>
                      </div>
                    </div>
                  </div>
                </li>
                <li class="glide__slide">
                  <div class="p-5">
                    <div class="card shadow-lg" style="width: 18rem; background-image: linear-gradient(to right, #e5e6e8, #28f7f7);" data-aos="zoom-in-down">
                      <div class="card-body">
                        <img class="rounded-circle img-thumbnail" src="img/tito.jpg" width="100" style="margin-top: -65px;">
                        <h6 class="card-subtitle mb-3 mt-3 text-muted">Tito Handaru</h6>
                        <p class="card-text">Desainnya dapat sesuai dengan apa yang diharapkan bagus banget pokoknye. Kerjanya juga cepat dan sangat baik, nanti kapan-kapan saya pesen lagi kak.</p>
                      </div>
                    </div>
                  </div>
                </li>
                <li class="glide__slide">
                  <div class="p-5">
                    <div class="card shadow-lg" style="width: 18rem; background-image: linear-gradient(to right, #e5e6e8, #28f7f7);" data-aos="fade-left">
                      <div class="card-body">
                        <img class="rounded-circle img-thumbnail" src="img/syifa.jpeg" width="100"  style="margin-top: -65px;">
                        <h6 class="card-subtitle mb-3 mt-3 text-muted">Asyifa Nur Fauzan</h6>
                        <p class="card-text">Terima kasih banyak kak, saya sangat puas dengan kinerja kakak, selain prosesnya cepat, responnya cepat, hasilnya pun sangat memuaskan. GOOD JOB !!!</p>
                      </div>
                    </div>
                  </div>
                </li>
                <li class="glide__slide">
                  <div class="p-5">
                    <div class="card shadow-lg" style="width: 18rem; background-image: linear-gradient(to right, #e5e6e8, #28f7f7);" data-aos="fade-left">
                      <div class="card-body">
                        <img class="rounded-circle img-thumbnail" src="img/dwipayana.jpeg" width="100"  style="margin-top: -65px;">
                        <h6 class="card-subtitle mb-3 mt-3 text-muted">Dwipayana</h6>
                        <p class="card-text">Gilasih bener-bener mirip sama muka aslinya, keren banget hasilnya. Recomend banget pokoknya make jasa Desainer milenial, nextime saya bakal pesen lagi ya kak..</p>
                      </div>
                    </div>
                  </div>
                </li>
                <li class="glide__slide">
                  <div class="p-5">
                    <div class="card shadow-lg" style="width: 18rem; background-image: linear-gradient(to right, #e5e6e8, #28f7f7);" data-aos="fade-left">
                      <div class="card-body">
                        <img class="rounded-circle img-thumbnail" src="img/hesekiel.jpeg" width="100"  style="margin-top: -65px;">
                        <h6 class="card-subtitle mb-3 mt-3 text-muted">Hesekiel Hutajulu</h6>
                        <p class="card-text">Bagus banget desainnya, waktu pengerjaanya juga cepet banget. Pelayanannya juga ramah banget. Terima kasih banyak kak, makin sukses kedepannya hehe..</p>
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
            <div class="glide__arrows text-center mt-2 mb-5" data-glide-el="controls">
              <i
                class="fas fa-arrow-alt-circle-left fa-3x text-white mr-5"
                class="glide__arrow glide__arrow--left m-5"
                data-glide-dir="<"
              ></i>
              <i
                class="fas fa-arrow-alt-circle-right text-white fa-3x"
                class="glide__arrow glide__arrow--right m-5"
                data-glide-dir=">"
              ></i>
           
            </div>
          </div>
        </div>
        <div class="row text-center mb-5">
          <div class="col-sm">
            <button type="button" class="btn btn-warning" style="border-radius: 20px;"><a href="testimoni.php" style="text-decoration: none; color: black; padding: 5px;">Lebih banyak testimoni <i class="bi bi-arrow-right-circle-fill"></i></a></button>
          </div>
        </div>
      </div>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
        <path
          fill="#e7003e"
          fill-opacity="1"
          d="M0,160L80,138.7C160,117,320,75,480,53.3C640,32,800,32,960,53.3C1120,75,1280,117,1360,138.7L1440,160L1440,0L1360,0C1280,0,1120,0,960,0C800,0,640,0,480,0C320,0,160,0,80,0L0,0Z"
        ></path>
      </svg>
    </section>
    <!-- akhir testimoni -->

    <!-- accordion -->
    <div class="row">
        <div class="col text-center">
          <h2 class="font-weight-bold" data-aos="fade-down">F A Q</h2>
        </div>
    </div>
    <div class="container accordion mt-5" id="accordionExample" data-aos="fade-left">
    <?php foreach ($accordion as $accord) : ?>
      <div class="card shadow">
        <div class="card-header" id="<?= $accord["id"]; ?>">
          <h2 class="mb-0">
            <button class="btn btn-block text-left colapsed" type="button" data-toggle="collapse" data-target="#<?= $accord["collapse"]; ?>" aria-expanded="false" aria-controls="<?= $accord["collapse"]; ?>">
              <h5>+ <?= $accord["judul"]; ?></h5>
            </button>
          </h2>
        </div>
        <div id="<?= $accord["collapse"]; ?>" class="collapse" aria-labelledby="<?= $accord["id"]; ?>" data-parent="#accordionExample">
          <div class="card-body">
            <p><?= $accord["pesan"]; ?></p>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
    </div>
    <!-- akhir accordion -->


    <!-- footer -->
    <?php 
    include 'footer.php';
    ?>
    <!-- akhir footer -->

