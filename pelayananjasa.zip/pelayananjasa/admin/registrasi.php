<?php 
require 'function.php';

if ( isset($_POST["register"]) ) {
    if ( registrasi($_POST) > 0) {
        echo "<script>
                alert('user baru berhasil ditambahkan');
            </script>";
    } else {
        echo mysqli_error($conn);
    }
}

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
      integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l"
      crossorigin="anonymous"
    />
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css" />
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;800;900&display=swap" rel="stylesheet" />

    <link rel="icon" type="img/png" href="../img/title.png">
    <title>Desainer Milenial | 2021</title>
    <style>
      /* Back To Top Pure JS by igniel.com */
      #ignielToTop {
        display: none;
        z-index: 2;
        position: fixed;
        bottom: 20px;
        right: 20px;
        border-radius: 2px;
        cursor: pointer;
        transition: all 0.4s;
        width: 35px;
        height: 35px;
        background: #ed2849
          url("data:image/svg+xml,%3Csvg viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M7.41,15.41L12,10.83L16.59,15.41L18,14L12,8L6,14L7.41,15.41Z' fill='%23fff'/%3E%3C/svg%3E")
          no-repeat center center;
      }

      nav a:hover {
        border-bottom: 4px solid white;
      }
    </style>
  </head>
  <body style="font-family: 'Poppins', sans-serif">
    <!-- Navbar -->
    <!-- <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top shadow">
      <div class="container-sm">
        <img src="img/logo.png" width="250" class="navbar-brand" />
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav" style="font-size: larger">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link pr-3" aria-current="page" href="#"><i class="bi bi-gear-fill"></i>Admin</a>
            </li>
            <li class="nav-item">
              <a class="nav-link pr-3" href="#">Gambar</a>
            </li>
            <li class="nav-item">
              <a class="nav-link pr-3" href="#">Testimoni</a>
            </li>
            <li class="nav-item">
              <a class="nav-link pr-3" href="#">Logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav> -->
    <!-- Akhir navbar -->

    <!-- tambah data -->
    <section>
      <div class="container" style="margin-top: 100px;">
        <div class="row text-center">
          <h2>Halaman Registrasi</h2>
        </div>
       <form action="" method="POST">
       <ul>
            <li>
                <label for="username">username :</label>
                <input type="text" name="username" id="username">
            </li>
            <li>
                <label for="password">password :</label>
                <input type="password" name="password" id="password">
            </li>
            <li>
                <label for="password2">konfirmasi password :</label>
                <input type="password" name="password2" id="password2">
            </li>
            <li>
                <button type="submit" name="register">Register</button>
            </li>
       </ul>
       </form>
      </div>
    </section>
    <!-- akhir tambah data -->

    <!-- footer -->
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#273036" fill-opacity="1" d="M0,288L1440,192L1440,320L0,320Z"></path></svg>
    <footer class="text-white pb-2 pt-3" style="background-color: #273036">
      <div class="container">
        <div class="row">
          <div class="col-sm-5" data-aos="fade-right">
            <h1 class="font-weight-bold pb-3">Talk to us</h1>
            <p class="text-muted">Email</p>
            <p>sawra_dhtri@gmail.com</p>
            <p class="text-muted">Phone</p>
            <p>+62895-3666-32705</p>
            <p class="text-muted">Sosial Media</p>
            <i class="bi bi-twitter"></i>
            <i class="bi bi-instagram"></i>
          </div>
          <div class="col-sm-7" data-aos="fade-left">
            <img src="../img/logo.png" width="250" class="navbar-brand" />
            <p>
              Kami adalah badan usaha yang bergerak di bidang seni digital jasa gambar/lukisan berwarna Kami hadir dengan tujuan membantu Anda dalam mendesain. Sebenarnya dunia desain sangat luas,
              namun kami lebih terfokus kepada implementasi lukis wajah. Klien kami sudah sangat banyak dan ada di daerah-daerah seluruh Indonesia untuk berbagai macam kebutuhan. Mulai dari kebutuhan
              pribadi maupun kelompok.
            </p>
          </div>
        </div>
        <hr style="background-color: white" />
        <h5 class="text-center">Dibuat dengan <i class="bi bi-heart-fill text-danger"></i> sawram dhavi</h5>
      </div>
    </footer>
    <!-- akhir footer -->

    <div id="ignielToTop" />
    <script>
      //<![CDATA[
      /* Back To Top Pure JS by igniel.com */
      var igniel_kecepatan = 1200; //kecepatan scroll
      var igniel_jarak = 300; //posisi munculnya tombol
      eval(
        (function (p, a, c, k, e, d) {
          e = function (c) {
            return (c < a ? '' : e(parseInt(c / a))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) : c.toString(36));
          };
          if (!''.replace(/^/, String)) {
            while (c--) {
              d[e(c)] = k[c] || e(c);
            }
            k = [
              function (e) {
                return d[e];
              },
            ];
            e = function () {
              return '\\w+';
            };
            c = 1;
          }
          while (c--) {
            if (k[c]) {
              p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c]);
            }
          }
          return p;
        })(
          'f 7=["\\h\\a\\g\\h\\F","\\C\\h\\w\\c\\a\\a\\l\\c\\v","\\e\\c\\h\\K\\p\\9\\d\\b\\m\\a\\9\\p\\9\\d\\b","\\G\\c\\e\\q","\\J\\e\\e\\m\\I\\9\\d\\b\\H\\g\\C\\b\\9\\d\\9\\w","\\g\\u\\d\\g\\9\\a\\l\\c\\l\\c\\v","\\u\\9\\b\\m\\a\\9\\p\\9\\d\\b\\M\\q\\U\\e"];8[7[6]](7[5])[7[4]](7[0],j x(){f i=8[7[2]][7[1]]||8[7[3]][7[1]];o(k<=0){s};f r=0-i;f t=r/k*X;L(j(){8[7[3]][7[1]]=8[7[2]][7[1]]=i+t;o(i==0){s};x(8[7[3]],0,k)},P)},Q);B.Y(\'O\',j(){o(B.N>=n||8.R.z>=n||8.W.z>=n){8.y(\'A\').E.D=\'V\'}T{8.y(\'A\').E.D=\'S\'}});',
          61,
          61,
          '|||||||_0x3e17|document|x65|x6C|x74|x6F|x6E|x64|var|x69|x63|_0x2ceax2|function|igniel_kecepatan|x54|x45|igniel_jarak|if|x6D|x79|_0x2ceax3|return|_0x2ceax4|x67|x70|x72|ignielScroll|getElementById|scrollTop|ignielToTop|window|x73|display|style|x6B|x62|x4C|x76|x61|x75|setTimeout|x42|pageYOffset|scroll|10|false|documentElement|none|else|x49|block|body|50|addEventListener'.split(
            '|'
          ),
          0,
          {}
        )
      );
      //]]>
    </script>

    <!-- Optional JavaScript; choose one of the two! -->
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
      crossorigin="anonymous"
    ></script>
    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns"
      crossorigin="anonymous"
    ></script>

    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>
    <script src="https://kit.fontawesome.com/1f3a0603f3.js" crossorigin="anonymous"></script>
  </body>
</html>
