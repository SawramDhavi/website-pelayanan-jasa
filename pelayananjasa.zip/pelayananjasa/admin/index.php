<?php 
session_start();

if ( !isset($_SESSION["login"]) ) {
  header("Location: login.php");
  exit;
}

require 'function.php';

// pagination konfigurasi
$jumlahDataPerHalaman = 10;
$jumlahData = count(query("SELECT * FROM portofolio"));
$jumlahHalaman = ceil($jumlahData / $jumlahDataPerHalaman);
$halamanAktif = ( isset($_GET["halaman"]) ) ? $_GET["halaman"] : 1;
$awalData = ($jumlahDataPerHalaman * $halamanAktif ) - $jumlahDataPerHalaman;


$portofolio = query("SELECT * FROM portofolio LIMIT $awalData, $jumlahDataPerHalaman");
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
      integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l"
      crossorigin="anonymous"
    />
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css" />
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />
    <!-- roboto -->
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700;900&display=swap" rel="stylesheet">

    <link rel="icon" type="img/png" href="../img/title.png">
    <title>Desainer Milenial | 2021</title>
    <style>
      /* Back To Top Pure JS by igniel.com */
      #ignielToTop {
        display: none;
        z-index: 2;
        position: fixed;
        bottom: 20px;
        right: 20px;
        border-radius: 2px;
        cursor: pointer;
        transition: all 0.4s;
        width: 35px;
        height: 35px;
        background: #ed2849
          url("data:image/svg+xml,%3Csvg viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M7.41,15.41L12,10.83L16.59,15.41L18,14L12,8L6,14L7.41,15.41Z' fill='%23fff'/%3E%3C/svg%3E")
          no-repeat center center;
      }

      nav a:hover {
        border-bottom: 4px solid white;
      }
    </style>
  </head>
  <body style="font-family: 'Roboto', sans-serif; background-image: url(img/admin-walpaper3.jpg); background-size: cover;">
    
    <!-- Navbar -->
    <?php 
    include 'navbar-admin.php';
    ?>
    <!-- Akhir navbar -->

    <!-- judul -->
    <div class="container" style="margin-top: 150px;">
        <div class="container  mb-5">
            <div class="row text-center">
                <div class="col-sm">
                    <h2 class="font-weight-bold">Tabel Data Admin</h2>
                </div>
            </div>
        </div>
    </div>
    <!-- akhir judul -->

    <!-- tabel -->
     <div class="container col-sm-10 offset-1">
        <button type="button" class="btn btn-warning mb-3"> <a href="tambah.php" style="text-decoration:none; color:black">Tambah Data</a></button>
            <div class=" table-responsive-smrow text-center">
            <table class="table table-bordered">
                <thead class="text-white">
                    <tr class="bg-info">
                    <th scope="col">No</th>
                    <th scope="col">Nama Pemesan</th>
                    <th scope="col">Kd_gambar</th>
                    <th scope="col">Gambar</th>
                    <th scope="col">Kategori</th>
                    <th scope="col">Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($portofolio as $row ) : ?>
                    <tr class="bg-light">
                    <td><?php echo $i.'.'; ?></td>
                    <td class="text-left"><?php echo $row["nama"]; ?></td>
                    <td><?php echo$row["kd_gambar"]; ?></td>
                    <td><img src="../img/<?= $row["gambar"]; ?>" width="100"></td>
                    <td><?php echo $row["kategori"]; ?></td>
                    <td>
                    <button type="button" class="btn btn-danger"> <a href="ubah.php?kd_gambar=<?= $row["kd_gambar"]; ?>" class="text-white" style="text-decoration:none" >Ubah</a></button>
                    <button type="button" class="btn btn-success"><a href="hapus.php?kd_gambar=<?= $row["kd_gambar"]; ?>" class="text-white" style="text-decoration:none" onclick="return confirm('yakin ingin dihapus ?');">Hapus</a></button>
                    </td>
                    </tr>
                    <?php $i++; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>
    <!-- akhir tabel -->

     <!-- navigasi -->
        <div class="container mb-5">
            <div class="row row justify-content-center">
                <div class="col-sm-2">
                <nav aria-label="Page navigation example">
                  <ul class="pagination">
                  <?php if($halamanAktif > 1 ) : ?>
                    <li class="page-item"><a class="page-link" href="?halaman=<?= $halamanAktif -1; ?>">Previous</a></li>
                  <?php endif; ?>
                  <?php for($i =1; $i <= $jumlahHalaman; $i++) : ?>
                    <li class="page-item"><a class="page-link" href="?halaman=<?= $i; ?>"><?= $i; ?></a></li>
                  <?php endfor; ?>
                  <?php if($halamanAktif < $jumlahHalaman ) : ?>
                    <li class="page-item"> <a class="page-link" href="?halaman=<?= $halamanAktif + 1; ?>">Next</a></li>
                  <?php endif; ?>
                  </ul>
                </nav>
                </div>
            </div>
        </div>
    <!-- akhir navigasi -->

    <!-- footer -->
    <?php 
    include 'footer-admin.php';
    ?>
    <!-- akhir footer -->

    
