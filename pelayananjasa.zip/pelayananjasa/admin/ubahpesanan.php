<?php 
require '../function-pesanan.php';

// ambil data di url
$email = $_GET["email"];
// query data mahasiswa berdasarkan id
$psn = query2("SELECT * FROM pesanan WHERE email = '$email'")[0];


// cek apakah tombol selesai sudah diklik atau belum
if ( isset($_POST["submit2"]) ) {
  
  // cek apakah pesanan berhasil diubah atau tidak
  if (ubah2($_POST) > 0 ) {
    echo "
        <script>
          alert('Data berhasil diubah !');
          document.location.href = 'pesanan.php';
        </script>
    ";
  } else {
    echo 
       mysqli_error($conn);
    ;
  }

}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
      integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l"
      crossorigin="anonymous"
    />
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css" />
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;800;900&display=swap" rel="stylesheet" />

    <link rel="icon" type="img/png" href="../img/title.png">
    <title>Desainer Milenial | 2021</title>
    <style>
      /* Back To Top Pure JS by igniel.com */
      #ignielToTop {
        display: none;
        z-index: 2;
        position: fixed;
        bottom: 20px;
        right: 20px;
        border-radius: 2px;
        cursor: pointer;
        transition: all 0.4s;
        width: 35px;
        height: 35px;
        background: #ed2849
          url("data:image/svg+xml,%3Csvg viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M7.41,15.41L12,10.83L16.59,15.41L18,14L12,8L6,14L7.41,15.41Z' fill='%23fff'/%3E%3C/svg%3E")
          no-repeat center center;
      }

      nav a:hover {
        border-bottom: 4px solid white;
      }
    </style>
  </head>
  <body style="font-family: 'Poppins', sans-serif">
    
    <!-- Navbar -->
   
    <!-- Akhir navbar -->

    <!-- ubah pemesanan -->
    <section>
    <div class="container-fluid" style="margin-top: 100px;">
        <div class="container pt-5">
            <div class="row">
                <div class="col-sm-6 offset-3 bg-light p-5 rounded shadow-lg">
                <h2 class="font-weight-bold text-center mb-5" data-aos="fade-down">Form <span class="text-danger"> pemesanan</span></h2>
                  <form action="" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="gambarLama" value="<?= $psn["gambar"]; ?>">
                    <div class="form-group">
                      <label for="nama">Nama</label>
                      <input type="text" name="nama" class="form-control" id="nama" required value="<?= $psn["nama"]; ?>"> 
                    </div>
                    <div class="form-group">
                      <label for="email">E-mail</label>
                      <input type="text" name="email" class="form-control" id="email" required value="<?= $psn['email']; ?>"> 
                    </div>
                    <div class="form-group">
                      <label for="nohp">No Hp</label>
                      <input type="text" name="nohp" class="form-control" id="nohp" required value="<?= $psn["nohp"]; ?>">
                    </div>
                    <div class="form-group">
                      <img src="../img/<?= $psn['gambar']; ?>" width="100">
                      <input type="file" class="pt-3 form-control-file" name="gambar" id="gambar">
                    </div>
                    <div class="input-group mb-3">
                      <div class="input-group-prepend">
                        <label class="input-group-text" for="inputGroupSelect01">Kategori</label>
                      </div>
                      <select class="custom-select" name="kategori" required>
                        <option selected>Choose...</option>
                        <option>wpap</option>
                        <option>sketch</option>
                        <option>lukisan</option>
                      </select>
                    </div>
                    <button type="submit" name="submit2" class="btn btn-danger">Ubah</button>
                  </form>
                </div>
            </div>
        </div>
    </div>
    </section>
    <!-- akhir ubah pemesanan -->

    <!-- footer -->
    <?php 
    include 'footer-admin.php';
    ?>
    <!-- akhir footer -->