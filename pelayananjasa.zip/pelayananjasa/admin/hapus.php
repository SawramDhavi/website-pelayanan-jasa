<?php  
session_start();

if ( !isset($_SESSION["login"]) ) {
  header("Location: login.php");
  exit;
}

require 'function.php';
$kd_gambar = $_GET["kd_gambar"];

if ( hapus($kd_gambar) > 0) {
	echo "
	<script>
	alert('data berhasil dihapus!');
	document.location.href = 'index.php'
	</script>
	";
} else {
	echo mysqli_error($conn);
} 

?>