<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark border-bottom border-light fixed-top shadow">
      <div class="container-sm">
        <img src="../img/logo.png" width="250" class="navbar-brand" />
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav" style="font-size: larger">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link pr-3" aria-current="page" href="index.php"><i class="bi bi-gear-fill"></i>Admin</a>
            </li>
            <li class="nav-item">
              <a class="nav-link pr-3" href="pesanan.php">Pesanan</a>
            </li>
            <li class="nav-item">
              <a class="nav-link pr-3" href="logout.php">Logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- Akhir navbar -->