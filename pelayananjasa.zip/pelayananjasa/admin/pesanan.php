<?php 
session_start();

if ( !isset($_SESSION["login"]) ) {
  header("Location: login.php");
  exit;
}
require '../function-pesanan.php';

$pesanan = query2("SELECT * FROM pesanan");

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
      integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l"
      crossorigin="anonymous"
    />
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css" />
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;800;900&display=swap" rel="stylesheet" />

    <link rel="icon" type="img/png" href="../img/title.png">
    <title>Desainer Milenial | 2021</title>
    <style>
      /* Back To Top Pure JS by igniel.com */
      #ignielToTop {
        display: none;
        z-index: 2;
        position: fixed;
        bottom: 20px;
        right: 20px;
        border-radius: 2px;
        cursor: pointer;
        transition: all 0.4s;
        width: 35px;
        height: 35px;
        background: #ed2849
          url("data:image/svg+xml,%3Csvg viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M7.41,15.41L12,10.83L16.59,15.41L18,14L12,8L6,14L7.41,15.41Z' fill='%23fff'/%3E%3C/svg%3E")
          no-repeat center center;
      }

      nav a:hover {
        border-bottom: 4px solid white;
      }
    </style>
  </head>
  <body style="font-family: 'Poppins', sans-serif; background-image: url(img/admin-walpaper3.jpg); background-size: cover;">
    
    <!-- Navbar -->
    <?php 
    include 'navbar-admin.php';
    ?>
    <!-- Akhir navbar -->

    <!-- judul -->
    <div class="container" style="margin-top: 150px;">
        <div class="container  mb-5">
            <div class="row text-center">
                <div class="col-sm">
                    <h2 class="font-weight-bold">Tabel Data Pesanan</h2>
                </div>
            </div>
        </div>
    </div>
    <!-- akhir judul -->

    <!-- tabel -->
     <div class="container col-sm-10 offset-1">
            <div class=" table-responsive-smrow text-center">
            <table class="table table-bordered">
                <thead class="text-white">
                    <tr class="bg-info">
                    <th scope="col">No</th>
                    <th scope="col">Nama Pemesan</th>
                    <th scope="col">Email</th>
                    <th scope="col">No Hp</th>
                    <th scope="col">Gambar</th>
                    <th scope="col">Kategori</th>
                    <th scope="col">Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                <?php $i = 1; ?>
                <?php foreach ( $pesanan as $row ) : ?>
                    <tr class="bg-light">
                    <td><?= $i; ?></td>
                    <td class="text-left"><?= $row["nama"]; ?></td>
                    <td><?= $row["email"]; ?></td>
                    <td><?= $row["nohp"]; ?></td>
                    <td><img src="../img/<?= $row["gambar"]; ?>" width="50"></td>
                    <td><?= $row["kategori"]; ?></td>
                    <td>
                    <button type="button" class="btn btn-danger  pl-3 pr-3"> <a href="ubahpesanan.php?email=<?= $row["email"]; ?>" class="text-white" style="text-decoration:none">Ubah</a></button>
                    <button type="button" class="btn btn-success"><a href="hapus-pesanan.php?email=<?= $row["email"]; ?>" onclick="return confirm('yakin ingin dihapus ?');" class="text-white" style="text-decoration:none">Hapus</a></button>
                    </td>
                    </tr>
                <?php $i++; ?>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>
    <!-- akhir tabel -->

    <!-- footer -->
    <?php 
    include 'footer-admin.php';
    ?>
    <!-- akhir footer -->
