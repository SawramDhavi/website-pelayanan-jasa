<!-- footer -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#273036" fill-opacity="1" d="M0,288L1440,192L1440,320L0,320Z"></path></svg>
    <footer class="text-white pb-2 pt-3" style="background-color: #273036">
      <div class="container">
        <div class="row">
          <div class="col-sm-5 pb-3" data-aos="fade-right">
            <h1 class="font-weight-bold pb-3">Talk to us</h1>
            <p class="text-muted">Email</p>
            <p>sawra_dhatri@gmail.com</p>
            <p class="text-muted">Phone</p>
            <p>+62895-3666-32705</p>
            <p class="text-muted">Sosial Media</p>
            <a href="https://twitter.com/viDhavii_"> <i class="bi bi-twitter text-white mr-2"></i></a>
            <a href="https://www.instagram.com/vidhavii/"> <i class="bi bi-instagram text-white"></i></a>
          </div>
          <div class="col-sm-7" data-aos="fade-left">
            <img src="../img/logo.png" width="250" class="navbar-brand">
            <p style="text-align: justify;">
              Kami adalah badan usaha yang bergerak di bidang seni digital jasa gambar/lukisan berwarna Kami hadir dengan tujuan membantu Anda dalam mendesain. Sebenarnya dunia desain sangat luas,
              namun kami lebih terfokus kepada implementasi lukis wajah. Klien kami sudah sangat banyak dan ada di daerah-daerah seluruh Indonesia untuk berbagai macam kebutuhan. Mulai dari kebutuhan
              pribadi maupun kelompok.
            </p>
          </div>
        </div>
        <hr style="background-color: white" />
        <h6 class="text-center text-muted">© 2021 made with <i class="bi bi-heart-fill text-danger"></i> by sawram dhavi</h6>
      </div>
    </footer>
    <!-- akhir footer -->

    
    <div id="ignielToTop" />
    <script>
      //<![CDATA[
      /* Back To Top Pure JS by igniel.com */
      var igniel_kecepatan = 1200; //kecepatan scroll
      var igniel_jarak = 300; //posisi munculnya tombol
      eval(
        (function (p, a, c, k, e, d) {
          e = function (c) {
            return (c < a ? '' : e(parseInt(c / a))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) : c.toString(36));
          };
          if (!''.replace(/^/, String)) {
            while (c--) {
              d[e(c)] = k[c] || e(c);
            }
            k = [
              function (e) {
                return d[e];
              },
            ];
            e = function () {
              return '\\w+';
            };
            c = 1;
          }
          while (c--) {
            if (k[c]) {
              p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c]);
            }
          }
          return p;
        })(
          'f 7=["\\h\\a\\g\\h\\F","\\C\\h\\w\\c\\a\\a\\l\\c\\v","\\e\\c\\h\\K\\p\\9\\d\\b\\m\\a\\9\\p\\9\\d\\b","\\G\\c\\e\\q","\\J\\e\\e\\m\\I\\9\\d\\b\\H\\g\\C\\b\\9\\d\\9\\w","\\g\\u\\d\\g\\9\\a\\l\\c\\l\\c\\v","\\u\\9\\b\\m\\a\\9\\p\\9\\d\\b\\M\\q\\U\\e"];8[7[6]](7[5])[7[4]](7[0],j x(){f i=8[7[2]][7[1]]||8[7[3]][7[1]];o(k<=0){s};f r=0-i;f t=r/k*X;L(j(){8[7[3]][7[1]]=8[7[2]][7[1]]=i+t;o(i==0){s};x(8[7[3]],0,k)},P)},Q);B.Y(\'O\',j(){o(B.N>=n||8.R.z>=n||8.W.z>=n){8.y(\'A\').E.D=\'V\'}T{8.y(\'A\').E.D=\'S\'}});',
          61,
          61,
          '|||||||_0x3e17|document|x65|x6C|x74|x6F|x6E|x64|var|x69|x63|_0x2ceax2|function|igniel_kecepatan|x54|x45|igniel_jarak|if|x6D|x79|_0x2ceax3|return|_0x2ceax4|x67|x70|x72|ignielScroll|getElementById|scrollTop|ignielToTop|window|x73|display|style|x6B|x62|x4C|x76|x61|x75|setTimeout|x42|pageYOffset|scroll|10|false|documentElement|none|else|x49|block|body|50|addEventListener'.split(
            '|'
          ),
          0,
          {}
        )
      );
      //]]>
    </script>

    <!-- Optional JavaScript; choose one of the two! -->
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
      crossorigin="anonymous"
    ></script>
    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns"
      crossorigin="anonymous"
    ></script>

    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>
    <script src="https://kit.fontawesome.com/1f3a0603f3.js" crossorigin="anonymous"></script>
  </body>
</html>