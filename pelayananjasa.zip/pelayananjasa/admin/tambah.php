<?php 
session_start();

if ( !isset($_SESSION["login"]) ) {
  header("Location: login.php");
  exit;
}
require 'function.php';

// cek apakah tombol submit sudah ditekan
if( isset($_POST["submit"]) ) {


// cek apakah data berhasil ditambahkan
  if ( tambah($_POST) > 0 ) {
    echo "
    <script>
    alert('data berhasil ditambahkan!');
    document.location.href = 'index.php'
    </script>
    ";
  } else {
    echo "
    <script>
    alert('data gagal ditambahkan!');
    document.location.href = 'index.php'
    </script>
    ";
  }
}

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
      integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css" />
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;800;900&display=swap" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">

    <link rel="icon" type="img/png" href="../img/title.png">
    <title>Desainer Milenial | 2021</title>
    <style>
      /* Back To Top Pure JS by igniel.com */
      #ignielToTop {
        display: none;
        z-index: 2;
        position: fixed;
        bottom: 20px;
        right: 20px;
        border-radius: 2px;
        cursor: pointer;
        transition: all 0.4s;
        width: 35px;
        height: 35px;
        background: #ed2849
          url("data:image/svg+xml,%3Csvg viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M7.41,15.41L12,10.83L16.59,15.41L18,14L12,8L6,14L7.41,15.41Z' fill='%23fff'/%3E%3C/svg%3E")
          no-repeat center center;
      }

      nav a:hover {
        border-bottom: 4px solid white;
      }
    </style>
  </head>
  <body style="font-family: 'Poppins', sans-serif">
    
    <!-- Navbar -->
    <?php 
    include 'navbar-admin.php';
    ?>
    <!-- Akhir navbar -->

     <!-- judul -->
     <div class="container mb-5" style="margin-top: 150px; font-family: 'Lobster', cursive;">
        <div class="container">
            <div class="row text-center">
                <div class="col-sm">
                    <h2 class="font-weight-bold" data-aos="fade-down">Tambah Data</h2>
                </div>
            </div>
        </div>
    </div>
    <!-- akhir judul -->

    <!-- Tambah data -->
    <section>
    <div class="container">
        <div class="container  mb-5">
            <div class="row">
                <div class="col-sm-6 offset-3">
                  <form action="" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                      <label for="kd_gambar">Kode gambar</label>
                      <input type="text" class="form-control" name="kd_gambar" id="kd_gambar" required autocomplete="off">
                    </div>
                    <div class="form-group">
                      <label for="nama">Nama</label>
                      <input type="text" name="nama" class="form-control" id="nama" required autocomplete="off">
                    </div>
                    <div class="form-group">
                      <label for="gambar">Pilih gambar</label>
                      <input type="file" class="form-control-file" name="gambar" id="gambar" required>
                    </div>
                    <div class="input-group mb-3">
                      <div class="input-group-prepend">
                        <label class="input-group-text" for="inputGroupSelect01">Kategori</label>
                      </div>
                      <select class="custom-select" name="kategori" required value="<?= $prt["kategori"]; ?>">
                        <option selected>Choose...</option>
                        <option>wpap</option>
                        <option>sketch</option>
                        <option>lukisan</option>
                        <option>Testimoni</option>
                      </select>
                    </div>
                    <button type="submit" name="submit" class="btn btn-danger">Tambah data</button>
                  </form>
                </div>
            </div>
        </div>
    </div>
    </section>
    <!-- Akhir tambah data -->

    <!-- footer -->
    <?php 
    include 'footer-admin.php';
    ?>
    <!-- akhir footer -->