<?php 
require '../function-pesanan.php';
$email = $_GET["email"];

if (hapus2($email) > 0 ) {
    echo "
        <script>
          alert('Data berhasil dihapus !');
          document.location.href = 'pesanan.php';
        </script>
    ";
} else {
    echo mysqli_error($conn);
}
?>