-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 30 Jun 2021 pada 16.50
-- Versi server: 10.4.14-MariaDB
-- Versi PHP: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pelayananjasa`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `accordion`
--

CREATE TABLE `accordion` (
  `id` varchar(20) NOT NULL,
  `collapse` varchar(20) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `pesan` text NOT NULL,
  `kategori` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `accordion`
--

INSERT INTO `accordion` (`id`, `collapse`, `judul`, `pesan`, `kategori`) VALUES
('1headingOne', 'collapseOne', 'Bagaimana caranya pemesanannya ?', 'Kamu pergi ke menu wpap, sketch atau lukisan warna. Setelah itu isi form pemesanan. Selanjutnya tim kami akan segera menghubungimu lewat WhatsApp', 'umum'),
('2headingTwo', 'collapseTwo', 'Bagaimana cara saya mengirim foto ?', 'Kamu bisa menguploadnya pada formulir pemesanan di pilihan upload foto, atau mengirimnya via WhatsApp nanti, jika ingin ganti foto.', 'umum'),
('3headingThree', 'collapseThree', 'Dikirim melalui apa jika prosesnya sudah selesai dikerjakan ?', 'Karena hasil dari jasa kami adalah berupa soft file maka akan kami kirim melalui email.', 'umum'),
('4headingFour', 'collapseFour', 'Berapa kali pelanggan boleh mengajukan revisi ?', 'Revisi setiap gambar atau lukisan maksimal 1 kali bersifat minor ( ganti latar, warna ) tidak untuk mengubah Objek Utama.', 'umum'),
('5headingFive', 'collapseFive', 'Apakah pelanggan dapat file mentahan .CDR/COREL DRAW ?', 'Ya, tentu saja. Kami akan menyertakan file mentahan berupa file .CDR Umumnya jasa vektor tidak akan memberikan file .CDR karena MAHAL Namun jika Kamu order di tempat kami, kami akan\r\n          memberikannya secara cuma-cuma.', 'umum'),
('6headingSix', 'collapseSix', 'Isi form pemesanan', 'Kepada pelanggan, langkah pertama jika ingin memesan jasa kami yaitu, mengisi form pemesanan, dan pastikan gambar tidak salah kirim.', 'pesanan'),
('7headingSeven', 'collapseSeven', 'Tim kami akan menghubungi', 'Setelah mengisi form pemesanan, kepada pelanggan di mohon menunggu, karena tim kami akan segera menghubungimu lewat WhatsApp.', 'pesanan'),
('8headingEight', 'collapseEight', 'Menunggu pesanan selesai', 'Jika pelanggan sudah mengisi form pemesanan, dan sudah konfirmasi pembayaran melalui WhatsApp. Pelanggan menunggu hasil Gambar beserta soft filenya, yang akan dikirim melalui email, agar gambar tidak pecah.', 'pesanan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int(3) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'sawramdhavi', '$2y$10$wKfnb.liWL.csHcvw9eRo.dJamaC10vvugaMT5yuIVoWGgQTBJBk2'),
(4, 'dhavisens', '$2y$10$8vgviQXqXxyKM5CcJmmJouzbLYn0hWY09HhgbbOkgnFy.T6Yy9TSa'),
(5, 'vidhavii', '$2y$10$Su7PlWzovX6Lt96WzSTRROXjj85GTvrad2mHkoWDJJCSpBWgYnrg6');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pesanan`
--

CREATE TABLE `pesanan` (
  `nama` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `nohp` varchar(13) NOT NULL,
  `gambar` varchar(30) NOT NULL,
  `kategori` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pesanan`
--

INSERT INTO `pesanan` (`nama`, `email`, `nohp`, `gambar`, `kategori`) VALUES
('asyifa nur fauzzan', 'syifahudjrael@gmail.com', '089362537486', '60dc7b1b4f6e7.jpeg', 'sketch');

-- --------------------------------------------------------

--
-- Struktur dari tabel `portofolio`
--

CREATE TABLE `portofolio` (
  `kd_gambar` char(7) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `gambar` varchar(30) NOT NULL,
  `kategori` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `portofolio`
--

INSERT INTO `portofolio` (`kd_gambar`, `nama`, `gambar`, `kategori`) VALUES
('KK01', 'sawram dhavi', '60dc190f52527.png', 'lukisan'),
('KK02', 'dhavisense', '60dc1928637e3.jpg', 'wpap'),
('KK03', 'Dinda ayu', '60dc193fc5f24.jpg', 'sketch'),
('KK04', 'alifa maulida nurulita', '60dc7a9e25ceb.jpg', 'Testimoni');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `accordion`
--
ALTER TABLE `accordion`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  ADD PRIMARY KEY (`email`) USING BTREE;

--
-- Indeks untuk tabel `portofolio`
--
ALTER TABLE `portofolio`
  ADD PRIMARY KEY (`kd_gambar`) USING BTREE;

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
