    <!-- navbar -->
    <?php  
    include 'navbar.php';
    ?>
    <!-- akhir navbar -->
    
    <!-- about us -->
    <section>
    <div class="container" style="margin-top: 100px;">
      <div class="row justify-content-center">
        <div class="col-sm-7">
          <h1 class="font-weight-bold" style="color: #e7003e; padding-top:80px;">Tentang Kami</h1>
          <p style="text-align: justify;">Berawal dari hobi saya (Sawra dhatri) yang gemar melukis untuk mengisi waktu luang. Tak sedikit teman saya yang meminta untuk dilukis wajahnya, waktu itu saya hanya menggambar sketch saja, seiring berjalannya waktu saya belajar untuk mewarnai gambar sketch yang telah saya buat, saya juga belajar membuat gambar wpap. Dari yang awalnya hobi, lama kelamaan semakin banyak tawaran menggambar dari situ saya melihat ini adalah peluang untuk saya membuka bisnis jasa menggambar.</p>
          <p style="text-align: justify;">Saya mulai memasarkan jasa saya melalui sosial media, dan hasilnya alhamdullilah banyak yang berminat dengan jasa saya, karena bisnis saya terus berkembang sayapun mengajak kenalan saya yang kebetulan bisa melukis juga, untuk berkolaborasi dalam tim.</p>
        </div>
        <div class="col-sm-5 text-end" style="margin-top: 30px;">
          <img src="img/aboutus2.jpg" width="100%">
        </div>
      </div>
    </div>
    </section>
    <!-- akhir about us -->

    <!-- footer -->
      <?php 
      include 'footer.php';
      ?>
    <!-- akhir footer -->

    <!-- Optional JavaScript; choose one of the two! -->
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
      crossorigin="anonymous"
    ></script>
    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns"
      crossorigin="anonymous"
    ></script>

    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>
    <script src="https://kit.fontawesome.com/1f3a0603f3.js" crossorigin="anonymous"></script>
  </body>
</html>
