<?php 
require 'function-pesanan.php';

function query($query) {
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while( $row = mysqli_fetch_assoc($result) ) {
		$rows[] = $row;
	}
	return $rows;
}

$portofolio = query("SELECT * FROM portofolio WHERE kategori='lukisan'");


// cek apakah tombol selesai sudah diklik atau belum
if ( isset($_POST["submit2"]) ) {
  
  // cek apakah pesanan berhasil ditambahkan atau tidak
  if (tambah($_POST) > 0 ) {
    echo "
        <script>
          alert('Data berhasil ditambahkan !');
        </script>
    ";
  } else {
    echo "
        <script>
          alert('Data gagal ditambahkan !');
        </script>
    ";
  }

}

?>
    
    <!-- navbar -->
    <?php  
    include 'navbar.php';
    ?>
    <!-- akhir navbar -->

    <!-- jumbotron -->
    <img src="img/lukisan2.jpg" class="img-fluid mt-5"/>
    <!-- akhir jumbotron -->

    <!-- form pemesanan -->
    <?php 
    include 'form-pemesanan.php';
    ?>
    <!-- akhir form pemesanan -->

     <!-- portofolio -->
     <section class="portofolio">
      <div class="container">
        <div class="row text-center mb-5" style="padding-top: 100px">
          <div class="col">
            <h2 class="font-weight-bold text-danger" data-aos="fade-down">Portofolio</h2>
          </div>
        </div>
        <div class="col text-center">
        <?php foreach ($portofolio as $row ) : ?>
          <img src="img/<?= $row["gambar"]; ?>" class="img-thumbnail m-3 shadow" width="300" data-aos="flip-right"> 
        <?php endforeach; ?>
        </div>
      </div>
    </section>
    <!-- akhir portofolio -->

    <!-- footer -->
    <?php 
    include 'footer.php';
    ?>
    <!-- akhir footer -->