<?php 
require 'function-pesanan.php';

function query($query) {
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while( $row = mysqli_fetch_assoc($result) ) {
		$rows[] = $row;
	}
	return $rows;
}

$portofolio = query("SELECT * FROM portofolio WHERE kategori='sketch'");


// cek apakah tombol selesai sudah diklik atau belum
if ( isset($_POST["submit2"]) ) {
  
  // cek apakah pesanan berhasil ditambahkan atau tidak
  if (tambah($_POST) > 0 ) {
    echo "
        <script>
          alert('Data berhasil ditambahkan !');
        </script>
    ";
  } else {
    echo mysql_error($conn);
  }

}

?>

   <!-- navbar -->
    <?php  
    include 'navbar.php';
    ?>
    <!-- akhir navbar -->

    <!-- jumbotron -->
    <img src="img/walpaper-sketch.png" class="img-fluid mt-5 mb-5" style="background-position: center; background-repeat: no-repeat; background-size:cover; background-position: center; position:relative; background-attachment: fixed;"/>
    <!-- akhir jumbotron -->

    <!-- form pemesanan -->
    <?php 
    include 'form-pemesanan.php';
    ?>
    <!-- akhir form pemesanan -->

     <!-- portofolio -->
     <section class="portofolio">
      <div class="container">
        <div class="row text-center mb-5" style="padding-top: 100px">
          <div class="col">
            <h2 class="font-weight-bold text-danger" data-aos="fade-down">Portofolio</h2>
          </div>
        </div>
        <div class="col text-center">
        <?php foreach ($portofolio as $row ) : ?>
          <img src="img/<?= $row["gambar"]; ?>" class="img-thumbnail m-3 shadow" width="300" data-aos="flip-right"> 
        <?php endforeach; ?>
        </div>
      </div>
    </section>
    <!-- akhir portofolio -->

    <!-- footer -->
    <?php 
    include 'footer.php';
    ?>
    <!-- akhir footer -->